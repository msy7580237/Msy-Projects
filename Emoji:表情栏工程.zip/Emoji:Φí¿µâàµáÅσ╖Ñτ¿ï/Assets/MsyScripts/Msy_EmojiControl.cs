﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


/// <summary>
/// Demo功能类
/// </summary>
public class Msy_EmojiControl : MonoBehaviour
{
    private Transform emojiContent, emojiPointsParent, pointBlack, pointTarget;
    private InputField emojiInputField;
    private Scrollbar emojiScrollbar;
    private Button emojiButton,button_msg;
    private GameObject emojiScrollView;
    private bool emojibox, isInit;
    [Tooltip("拖拽容差")]
    public float offset = 0.1f;
    // Start is called before the first frame update
    void Start()
    {
        Init();

        //表情栏窗口开关
        emojiButton.onClick.AddListener(() =>
        {
            if (emojibox)
                emojibox = false;
            else
                emojibox = true;
            emojiScrollView.gameObject.SetActive(emojibox);
        });

        button_msg.onClick.AddListener(() =>
        {
            Debug.Log("发送消息"+emojiInputField.text);
            emojiInputField.text = " ";
            emojiInputField.text = ""; 
        });
        //生成Emoji列表
        foreach (var item in Resources.Load<EmojiData>("EmojiData/EmojiData").datas)
        {
            GameObject m_obj = Instantiate(Resources.Load<GameObject>("emojiPrefab"), emojiContent);
            m_obj.name = item.key;
            m_obj.GetComponent<Button>().onClick.AddListener(
                delegate { EmojiButtonAddListener(item.key); });
            m_obj.GetComponent<Image>().sprite = item.sprite;
        }
        //生成滑动栏小白点
        for (int i = 0; i < Msy_ScrollRectHelper.instance.listItem.Count; i++)
        {
            Debug.Log("生成小白点" + (i + 1) + "于" + emojiPointsParent.name + "身上");
            Instantiate(Resources.Load<GameObject>("pointWhite"), emojiPointsParent).name = "point"+i;
        }
        StartCoroutine(PointAnim());
    }

    IEnumerator PointAnim()
    {
        yield return null;
        emojiScrollView.SetActive(false);
        pointBlack.position = emojiPointsParent.Find("point0").position;
        while (true)
        {
            pointBlack.position =
               Vector3.Lerp(pointBlack.position,
               emojiPointsParent.Find("point" + Msy_ScrollRectHelper.instance.nowindex).position,
               Time.deltaTime * Msy_ScrollRectHelper.instance.smooting);
            yield return null;
        }
    }

    private void Init()
    {
        emojiScrollView = transform.Find("Scroll View").gameObject;
        emojiContent = emojiScrollView.transform.Find("Viewport/emojiContent");
        emojiInputField = transform.Find("InputField").GetComponent<InputField>();
        emojiScrollbar = emojiScrollView.transform.Find("Scrollbar Horizontal").GetComponent<Scrollbar>();
        emojiButton = transform.Find("bt_emoji").GetComponent<Button>();
        emojiPointsParent = emojiScrollbar.transform.Find("ui_Points");
        pointBlack = emojiScrollbar.transform.Find("pointBlack");
        button_msg = transform.Find("bt_Msg").GetComponent<Button>();
    }

    void EmojiButtonAddListener(string buttonName)
    {
        Debug.Log(buttonName);
        emojiInputField.text += buttonName;
    }


  
}
